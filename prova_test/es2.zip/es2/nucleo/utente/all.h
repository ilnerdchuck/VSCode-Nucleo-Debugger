/// @file all.h
/// @brief File da includere nei programmi utente
#pragma once

#include <costanti.h>
#include <libce.h>
#include <sys.h>
#include <io.h>
#include "lib.h"
