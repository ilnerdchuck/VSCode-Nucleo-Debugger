Dispensa: <https://calcolatori.iet.unipi.it/resources/nucleo.pdf>
